## 一. 使用方法
```
1. 准备好oemapp的文件目录，假设它的路径为xxx
2. pagesize默认是2k，可以设置成4k

sh mkoemapp.sh --srcdir xxx --dmverity --pagesize 4k
```

