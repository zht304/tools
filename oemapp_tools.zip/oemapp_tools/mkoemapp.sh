#!/bin/sh

# Script Tools
MKSQUASHFS="mksquashfs"
MKUBIFS="mkfs.ubifs"
UBIFS_ARGS="${MKUBIFS_ARGS}"
Squashfs_ARGS="-noappend"
UBINIZE_ARGS="-m 2048 -p 128KiB -s 2048"
UBI_2K="-m 2048 -p 128KiB -s 2048"
UBI_4K="-m 4096 -p 256KiB -s 4096"

# Script DIR
PWDDIR=`cd \`dirname $0\`;pwd`
OUTDIR="${PWDDIR}/target"
SRCDIR=""

# Target Name
OEMAPP_Squashfs="oemapp.squashfs"
OEMAPP_UBI="oemapp.ubi"
OEMAPP_UBINIZE="oemapp.cfg"

# Image for DM-Verity
PrivateKey="RootCA_PrivateKey.pem"
OEMAPP_HashTree="ql-oemapp-hashtree-mdm9607.bin"
OEMAPP_RootHash="ql-oemapp-roothash.bin"
OEMAPP_RootHashSign="ql-oemapp-roothash.sign"
OEMAPP_RootCert="RootCA_Certificate.pem"

# DM Aargs
Quectel_DM="False"

ARGS=`getopt -o "p:t:s:o:d" -l "topdir:,srcdir:,option:,dmverity,pagesize:" -n "getopt.sh" -- "$@"`
eval set -- "${ARGS}"

Error()
{
    local text="${1}"
    echo -e "\033[31m${1}\033[0m"
}

mkfs_image()
{
    local fstype="${1}"
    local srcdir="${2}"
    local outimg="${3}"
    local imageargs="${4}"
    local ret="1"
    
    case "${fstype}" in
    "squashfs")
        fakeroot ${MKSQUASHFS} "${srcdir}" "${outimg}" ${imageargs}
        ret=$?
        ;;
    "ubifs")
        fakeroot ${MKUBIFS} -r "${srcdir}" -o "${outimg}" ${imageargs}
        ret=$?
        ;;
    *)
        Error "Fstype is not support in the SDK"
        ;;
    esac

    if [ ${ret} -ne 0 ];then
        Error "Generted ubifs image failed! Please check it!!!"
        Error "fs type : ${fstype}"
        Error "root dir: ${srcdir}"
        Error "output  : ${outimg}"
        Error "ubiargs : ${imageargs}"
        exit 1
    fi
    
    return 0
}

mkubimg_oemapp_squashfs()
{
    local srcdir="${1}"
    local imageargs="${2}"
    local outimg="${OUTDIR}/${OEMAPP_Squashfs}"
    local oem_ubi="${OUTDIR}/${OEMAPP_UBI}"
    local ubinizecfg="${PWDDIR}/${OEMAPP_UBINIZE}"
    
    mkfs_image "squashfs" "${srcdir}" "${outimg}" "${imageargs}"
    
    if [ "${Quectel_DM}" = "True" ];then
    	hashtreefile="${OUTDIR}/${OEMAPP_HashTree}"
    	roothashfile="${OUTDIR}/${OEMAPP_RootHash}"
    	roothashsignfile="${OUTDIR}/${OEMAPP_RootHashSign}"
    	pkeyfile="${PWDDIR}/dm/${PrivateKey}"
    	
    	cp -f "${PWDDIR}/dm/${OEMAPP_RootCert}" "${OUTDIR}"
    	roothash=`veritysetup format ${outimg} "${hashtreefile}" | grep "Root hash"`
    	echo ${roothash} | sed 's/.*Root hash: \(.*\)/\1/g' > "${roothashfile}"
    	openssl rsautl -sign -in ${roothashfile} -inkey ${pkeyfile} -out ${roothashsignfile}
    	cd "${PWDDIR}"
    	ubinize -o ${oem_ubi} ${UBINIZE_ARGS} ${ubinizecfg}
    fi
}

Handle_ShellArgs()
{
    while true
    do
        case "${1}" in
            -s|--srcdir)
            SRCDIR=`cd ${2} && pwd`
            shift 2;
            ;;
            
            -p|--pagesize)
            [ ${2} = "4k" ] && UBINIZE_ARGS="${UBI_4K}"
            shift 2;
            ;;
            
            -d|--dmverity)
            Quectel_DM="True"
            shift
            ;;
            
            --)
            shift;
            break;
            ;;
        esac
    done
}

main()
{
    Handle_ShellArgs $*
    if [ ! -e "${OUTDIR}" ];then
        mkdir -p ${OUTDIR}
    fi
    mkubimg_oemapp_squashfs "${SRCDIR}" "${Squashfs_ARGS}"
}

main $*

